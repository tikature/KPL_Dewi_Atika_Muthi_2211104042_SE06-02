const BankTransferApp = require('./app/BankTransferApp');

const app = new BankTransferApp();
app.run();